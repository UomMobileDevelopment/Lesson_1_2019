package com.example.myapplication;

public interface Product {


    double calculateProfit(double amount);
}
